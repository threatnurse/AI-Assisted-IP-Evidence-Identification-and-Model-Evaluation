import pandas as pd, re, ipaddress, csv, os

SRC = os.path.expanduser("~/cip_b107_lab/originals/dataset_small.csv")
OUT = os.path.expanduser("~/cip_b107_lab/outputs/candidate_review.csv")

df = pd.read_csv(SRC)

# Original labels are A/B/C/E/N — map to the binary scheme used in the JSONL split.
# We record BOTH so the report can show the mapping explicitly.
positive_classes = {"A"}   # original preprocessing collapsed A → positive
df["binary_label"] = df["class"].apply(lambda c: "positive" if c in positive_classes else "negative")

IP_RE = re.compile(r'\b(\d{1,3}(?:\.\d{1,3}){3})\b')

def strict_valid(s):
    try:
        ipaddress.IPv4Address(s); return True
    except Exception:
        return False

rows = []
for idx, r in df.iterrows():
    text = str(r['text'])
    # Every row has exactly one intended candidate (the 'ip' column) and it is always in 'text'
    rows.append({
        "source_row": idx,
        "context": text,
        "candidate_in_text": r['ip'],              # the substring the source labels
        "regex_would_match": bool(IP_RE.search(text)),
        "candidate_strict_valid": strict_valid(str(r['ip'])),
        "source_class": r['class'],
        "source_label_binary": r['binary_label'],
        "analyst_note": ""
    })

with open(OUT, "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    w.writeheader(); w.writerows(rows)

print(f"Wrote {len(rows)} rows to {OUT}\n")

print("=== A. Class → strict_valid crosstab ===")
df["strict_valid"] = df["ip"].apply(lambda x: strict_valid(str(x)))
print(pd.crosstab(df["class"], df["strict_valid"], margins=True))

print("\n=== B. Strict-valid but labeled NEGATIVE (the forensic gotchas) ===")
gotchas = df[(df["strict_valid"]) & (~df["class"].isin(positive_classes))]
print(gotchas[["ip","class","text"]].head(10).to_string(max_colwidth=70))
print(f"\nTotal strict-valid-but-negative: {len(gotchas)}")

print("\n=== C. Class counts, binary collapsed ===")
print(df["binary_label"].value_counts())

print("\n=== D. Ten varied samples for the report table ===")
# Choose representatives from each class
for cls in ["A","N","B","C","E"]:
    subset = df[df["class"]==cls]
    if len(subset):
        s = subset.iloc[0]
        print(f"[{cls}] ip={s['ip']!r:20s} strict_valid={strict_valid(s['ip'])!s:5s} text={s['text'][:60]!r}")
