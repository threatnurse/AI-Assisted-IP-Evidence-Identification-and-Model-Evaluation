import csv, hashlib, os
from datetime import datetime

originals = os.path.expanduser("~/cip_b107_lab/originals")
outputs   = os.path.expanduser("~/cip_b107_lab/outputs")
os.makedirs(outputs, exist_ok=True)

files = [
    "dataset_small.csv",
    "dataset_train.jsonl",
    "dataset_test.jsonl",
    "result.csv",
    "fine_tuning_steps.txt",
]

rows = []
for fn in files:
    p = os.path.join(originals, fn)
    if not os.path.exists(p):
        print(f"[WARN] missing file: {p}")
        continue
    h = hashlib.sha256(open(p, "rb").read()).hexdigest()
    rows.append({
        "filename": fn,
        "sha256": h,
        "bytes": os.path.getsize(p),
        "collection_time_wat": datetime.now().strftime("%Y-%m-%d %H:%M:%S WAT"),
        "transfer_source": "ICDFA capstone project",
        "examiner": "HAUWA HARUNA YAHAYA",
    })

out = os.path.join(outputs, "evidence_manifest.csv")
with open(out, "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    w.writeheader()
    w.writerows(rows)

print(f"Manifest written: {out}")
print(f"Rows: {len(rows)}")
