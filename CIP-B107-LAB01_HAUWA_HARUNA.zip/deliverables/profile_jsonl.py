import json
from collections import Counter
import os

for fn in ["dataset_train.jsonl","dataset_test.jsonl"]:
    path = os.path.expanduser(f"~/cip_b107_lab/originals/{fn}")
    labels = Counter(); n=0; bad=0
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line: continue
            try:
                o = json.loads(line); n += 1
                labels[o["completion"].strip()] += 1
            except Exception:
                bad += 1
    print(f"{fn}: records={n}, bad_json_lines={bad}, label_balance={dict(labels)}")

# Leakage check: exact text overlap between train and test prompts
def load(path):
    out=[]
    with open(path) as f:
        for line in f:
            if line.strip():
                out.append(json.loads(line)["prompt"])
    return out

tr = load(os.path.expanduser("~/cip_b107_lab/originals/dataset_train.jsonl"))
te = load(os.path.expanduser("~/cip_b107_lab/originals/dataset_test.jsonl"))
print(f"\nTrain prompts: {len(tr)}, Test prompts: {len(te)}")
print(f"Exact prompt overlap across train/test: {len(set(tr) & set(te))}")

