import pandas as pd
import os, re

SRC = os.path.expanduser("~/cip_b107_lab/originals/dataset_small.csv")
df = pd.read_csv(SRC)

print("=== 1. Class distribution (full) ===")
print(df['class'].value_counts(dropna=False))
print(f"\nTotal: {len(df)}")

print("\n=== 2. Cross-tab: class vs. whether 'text' contains a strict-valid IPv4 ===")
import ipaddress
IP_RE = re.compile(r'\b(\d{1,3}(?:\.\d{1,3}){3})\b')
def has_strict_ipv4(s):
    for m in IP_RE.finditer(str(s)):
        try:
            ipaddress.IPv4Address(m.group(1)); return True
        except: pass
    return False

df['has_strict_ipv4'] = df['text'].apply(has_strict_ipv4)
print(pd.crosstab(df['class'], df['has_strict_ipv4'], margins=True))

print("\n=== 3. Duplicate analysis ===")
print(f"Fully duplicated rows: {df.duplicated().sum()}")
print(f"Duplicated by 'text' only: {df.duplicated(subset=['text']).sum()}")
print(f"Duplicated by ('text','class') pair: {df.duplicated(subset=['text','class']).sum()}")

# Show the most-duplicated 'text' values
dup_texts = df[df.duplicated(subset=['text'], keep=False)].sort_values('text')
print(f"\nUnique text values that appear more than once: {dup_texts['text'].nunique()}")
print("\nTop 5 most repeated text values:")
print(dup_texts['text'].value_counts().head(5))

print("\n=== 4. Sample rows per class (2 each) ===")
for cls in df['class'].unique():
    print(f"\n--- class = {cls} ---")
    print(df[df['class']==cls][['ip','text']].head(2).to_string(max_colwidth=70))

print("\n=== 5. Cross-check: is the 'ip' column always present in 'text'? ===")
def ip_in_text(row):
    return str(row['ip']) in str(row['text'])
df['ip_in_text'] = df.apply(ip_in_text, axis=1)
print(df['ip_in_text'].value_counts())
print("\nRows where ip NOT in text (first 5):")
print(df[~df['ip_in_text']][['ip','class','text']].head(5).to_string(max_colwidth=70))
