import pandas as pd
import re, os

SRC = os.path.expanduser("~/cip_b107_lab/originals/dataset_small.csv")
df = pd.read_csv(SRC)

print("=== dataset_small.csv profile ===")
print("Records:", len(df))
print("Columns:", list(df.columns))
print("\nDtypes:\n", df.dtypes)
print("\nNull counts:\n", df.isnull().sum())
print("\nDuplicated rows:", int(df.duplicated().sum()))

# label distribution — detect the label column name
label_cols = [c for c in df.columns if 'label' in c.lower()]
print("\nLabel-like columns found:", label_cols)
for c in label_cols:
    print(f"\nValue counts for '{c}':")
    print(df[c].value_counts(dropna=False))

print("\n=== Head (first 5 rows) ===")
print(df.head(5).to_string(max_colwidth=60))

# IP-like token presence
ip_pat = re.compile(r'\b\d{1,3}(?:\.\d{1,3}){3}\b')
text_col = None
for candidate in ["trimmed_text","text","prompt","line","content"]:
    if candidate in df.columns:
        text_col = candidate
        break
if text_col:
    has_ip = df[text_col].astype(str).str.contains(ip_pat)
    print(f"\nText column used: '{text_col}'")
    print(f"Rows containing IP-like token: {int(has_ip.sum())} / {len(df)}")
