import pandas as pd
import os

BASE = os.path.expanduser("~/cip_b107_lab")
df = pd.read_csv(f"{BASE}/outputs/ml_predictions.csv")

# 1. Calculate Metrics
tp = len(df[(df.actual==1) & (df.predicted==1)])
fp = len(df[(df.actual==0) & (df.predicted==1)])
fn = len(df[(df.actual==1) & (df.predicted==0)])
tn = len(df[(df.actual==0) & (df.predicted==0)])

print("=== 1. Evaluation Metrics ===")
print(f"TP: {tp}, FP: {fp}, FN: {fn}, TN: {tn}")
accuracy = (tp + tn) / len(df)
precision = tp / (tp + fp) if (tp+fp) > 0 else 0
recall = tp / (tp + fn) if (tp+fn) > 0 else 0
f1 = 2 * (precision * recall) / (precision + recall) if (precision+recall) > 0 else 0

print(f"Accuracy:  {accuracy:.4f}")
print(f"Precision: {precision:.4f}")
print(f"Recall:    {recall:.4f}")
print(f"F1-Score:  {f1:.4f}")

# 2. Extract 8 analyst review records (4 False Positives, 4 True Positives)
# We pick the highest-scoring FPs to show where the model was most "confident" but wrong.
fps = df[df.tag == 'FP'].sort_values(by='score_positive', ascending=False)
tps = df[df.tag == 'TP'].sort_values(by='score_positive', ascending=False)

print("\n=== 2. Analyst Review Samples ===")
print("\n--- False Positives (Model predicted POSITIVE, Truth is NEGATIVE) ---")
for i, row in fps.head(4).iterrows():
    print(f"\n[FP] Truth: Negative | Prediction: Positive (Score: {row['score_positive']:.4f})")
    print(f"Text: {row['text']}")

print("\n--- True Positives (Model predicted POSITIVE, Truth is POSITIVE) ---")
for i, row in tps.head(4).iterrows():
    print(f"\n[TP] Truth: Positive | Prediction: Positive (Score: {row['score_positive']:.4f})")
    print(f"Text: {row['text']}")
