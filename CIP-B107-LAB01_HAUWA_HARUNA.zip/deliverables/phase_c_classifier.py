import json, re, random, os
import numpy as np, pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (confusion_matrix, classification_report,
                             accuracy_score, precision_score, recall_score,
                             f1_score, roc_auc_score)
import ipaddress
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.metrics import ConfusionMatrixDisplay

SEED = 42
random.seed(SEED); np.random.seed(SEED)

BASE = os.path.expanduser("~/cip_b107_lab")
def load(path):
    X, y = [], []
    with open(path) as f:
        for line in f:
            if not line.strip(): continue
            o = json.loads(line)
            X.append(o["prompt"]); y.append(1 if o["completion"].strip()=="positive" else 0)
    return X, y

train_X, train_y = load(f"{BASE}/originals/dataset_train.jsonl")
test_X,  test_y  = load(f"{BASE}/originals/dataset_test.jsonl")
print(f"Train: {len(train_X)}  Test: {len(test_X)}")

# ---- Leakage documented (do not remove rows; report them) ----
overlap = len(set(train_X) & set(test_X))
print(f"Exact prompt overlap train↔test: {overlap} / {len(test_X)} test prompts")

# ---- ML: TF-IDF char n-grams + LogisticRegression ----
vec = TfidfVectorizer(analyzer="char_wb", ngram_range=(3,5), min_df=1)
Xtr = vec.fit_transform(train_X)      # fit ONLY on train
Xte = vec.transform(test_X)

clf = LogisticRegression(max_iter=2000, random_state=SEED)
clf.fit(Xtr, train_y)

ml_pred  = clf.predict(Xte)
ml_score = clf.predict_proba(Xte)[:, 1]

print("\n=== ML Classifier (holdout) ===")
print(classification_report(test_y, ml_pred, digits=4))
print("Confusion matrix:\n", confusion_matrix(test_y, ml_pred))

# ---- Rule-based baseline on the same holdout ----
IP_RE = re.compile(r'\b(\d{1,3}(?:\.\d{1,3}){3})\b')
def valid(s):
    try: ipaddress.IPv4Address(s); return True
    except: return False

def baseline(prompt):
    return 1 if any(valid(m.group(1)) for m in IP_RE.finditer(prompt)) else 0

base_pred = [baseline(t) for t in test_X]
print("\n=== Rule-based Baseline (strict ipaddress only) ===")
print(classification_report(test_y, base_pred, digits=4))
print("Confusion matrix:\n", confusion_matrix(test_y, base_pred))

# ---- Metrics for BOTH, saved to CSV ----
def metrics(y, p, name):
    return {
        "model": name,
        "accuracy": accuracy_score(y, p),
        "precision": precision_score(y, p, zero_division=0),
        "recall": recall_score(y, p, zero_division=0),
        "f1": f1_score(y, p, zero_division=0),
    }

mrows = [metrics(test_y, ml_pred, "tfidf_logreg"),
         metrics(test_y, base_pred, "regex_plus_ipaddress")]

# Majority baseline
maj = max(test_y.count(0), test_y.count(1)) / len(test_y)
mrows.append({"model":"majority_class","accuracy":maj,"precision":None,"recall":None,"f1":None})

# AUROC / AUPRC only for models with scores (ML only)
try:
    from sklearn.metrics import average_precision_score
    mrows[0]["auroc"] = roc_auc_score(test_y, ml_score)
    mrows[0]["auprc"] = average_precision_score(test_y, ml_score)
except Exception as e:
    print("AUROC failed:", e)

pd.DataFrame(mrows).to_csv(f"{BASE}/outputs/metrics_comparison.csv", index=False)

# ---- Predictions table with TP/FP/FN/TN tags ----
def tag(a,p):
    return "TP" if (a==1 and p==1) else "FP" if (a==0 and p==1) else "FN" if (a==1 and p==0) else "TN"

pd.DataFrame({
    "text": test_X, "actual": test_y, "predicted": ml_pred,
    "score_positive": ml_score, "tag": [tag(a,p) for a,p in zip(test_y, ml_pred)]
}).to_csv(f"{BASE}/outputs/ml_predictions.csv", index=False)

# ---- Confusion matrix plot (ML) ----
fig, ax = plt.subplots(figsize=(4.5,4))
ConfusionMatrixDisplay(confusion_matrix(test_y, ml_pred),
                       display_labels=["negative","positive"]).plot(ax=ax, colorbar=False)
ax.set_title("TF-IDF + LogisticRegression\n(provided JSONL holdout)")
fig.tight_layout()
fig.savefig(f"{BASE}/outputs/cm_ml.png", dpi=150)
print("\nSaved: metrics_comparison.csv, ml_predictions.csv, cm_ml.png")
