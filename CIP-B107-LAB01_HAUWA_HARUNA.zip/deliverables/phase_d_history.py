import pandas as pd, os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

BASE = os.path.expanduser("~/cip_b107_lab")
r = pd.read_csv(f"{BASE}/originals/result.csv")

print("=== 1. Columns in result.csv ===")
print(list(r.columns))
print(f"\nRows: {len(r)}")
print("\nNon-null counts per column:")
print(r.notna().sum())
print("\nTail (last 3 rows):")
print(r.tail(3).to_string())

# 2. Training loss vs step
if 'training_loss' in r.columns:
    fig, ax = plt.subplots(figsize=(6,4))
    ax.plot(r['step'], r['training_loss'], color='darkred')
    ax.set_xlabel("step"); ax.set_ylabel("training_loss")
    ax.set_title("Historical fine-tune: training loss vs step")
    fig.tight_layout(); fig.savefig(f"{BASE}/outputs/hist_trainloss.png", dpi=150)

# 3. Classification accuracy vs step (if present)
if 'classification/accuracy' in r.columns:
    sub = r[r['classification/accuracy'].notna()]
    print(f"\nclassification/accuracy non-null rows: {len(sub)}")
    if len(sub) > 0:
        fig, ax = plt.subplots(figsize=(6,4))
        ax.plot(sub['step'], sub['classification/accuracy'], color='darkblue')
        ax.set_xlabel("step"); ax.set_ylabel("classification/accuracy")
        ax.set_title("Historical fine-tune: classification accuracy vs step")
        fig.tight_layout(); fig.savefig(f"{BASE}/outputs/hist_classacc.png", dpi=150)

# 4. Report final non-null value of each classification/* metric
print("\n=== 2. Final non-null classification metrics (Historical) ===")
for c in r.columns:
    if 'classification' in c:
        nn = r[c].dropna()
        if len(nn) > 0:
            print(f"{c}: {nn.iloc[-1]}")
        else:
            print(f"{c}: ALL NULL (no independent holdout metric recorded)")

# 5. Final training metrics
print("\n=== 3. Final training metrics (NOT holdout) ===")
for c in ['training_loss', 'training_sequence_accuracy', 'training_token_accuracy']:
    if c in r.columns:
        nn = r[c].dropna()
        if len(nn) > 0:
            print(f"{c}: {nn.iloc[-1]}")
